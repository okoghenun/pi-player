var Client = function(){
	this.id = 'c' + guid();
};

var curClient = new Client();