

//Preprocessing Plugins
//@prepros-append ../bower_components/jquery.cookie/jquery.cookie.js
//@prepros-append ../bower_components/jquery-placeholder/jquery.placeholder.js
//@prepros-append ../bower_components/fastclick/lib/fastclick.js

//Foundation plugins
//@prepros-append ../bower_components/foundation/js/foundation/foundation.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.topbar.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.reveal.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.dropdown.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.abide.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.alert.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.tab.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.joyride.js
//@prepros-append ../bower_components/foundation/js/foundation/foundation.tooltip.js


//Other Plugins

// App Declaration

